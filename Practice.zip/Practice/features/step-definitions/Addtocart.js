const {Given,When,Then} = require('cucumber');

Given(/^launch the url$/, function(){
browser.url("http://automationpractice.com/index.php");
}) 
And (/^login with valid credential$/, function(){
    browser.element("//input[@id='email']").setValue("shwetha");
    browser.element("//input[@id='passwd']").setValue("Tention123");
    browser.click("//button[@id='SubmitLogin']");
})
When(/^search with"printed summer wear"$/, function(){
    browser.element("//input[@id='search_query_top']").setValue("printed summer wear");
    browser.element("//button[@name='submit_search']").click();
    browser.waitForExist('.single_add_to_cart_button.button', 5000);
    it.skip("should scroll to printed summer wear", function(){
      console.log("printed summer wear", crmPage.addtocart.isDisplayedInViewport());
      crmPage.addtocart.scrollIntoView();
      
    })
})
And (/^add printed summer dress to cart by clicking on"add to cart" button$/, function(){
    browser.click("//*[@id='center_column']/ul/li[1]/div/div[2]/div[2]/a[1]/span");
  })

Then (/^verify the popup with message "product successfully added to your shopping cart"$/, function(){
      browser.waitForExist('.Product successfully added to your shopping cart', 5000);
      var msg = browser.getText('.Product successfully added to your shopping cart').trim();
      assert(msg === 'Product successfully added to your shopping cart.', 'Did not see the successfully message');

})
And (/^user should be able to proceed with checkout$/, function(){
     browser.click("//a[@title='Proceed to checkout']");
})
