const {Given,When,Then} = require('cucumber');

//cucumberOpts.ignoreUndefinedDefinitions as true();

Given('I go to the website',() => {
    browser.url("//http:automationpractice.com");
    });

When (/^I login with default user$/, function(){
    browser.element("//input[@id='email']").setValue("shwetha");
    browser.element("//input[@id='passwd']").setValue("Tention123");
    browser.elementClick("//button[@id='SubmitLogin']");

});

Then (/^I should see a homepage$/, function(){
    var strUrl =browser.getUrl();
    console.log("URL is : "+strUrl);

});   