import {Given,When,Then} from 'cucumber';

//creating account

Given (/^launch the url$/, function(){
      browser.url("http://automationpractice.com");
});
When (/^Start to type your When step here click on the "Signin" button from the top blank banner$/, function(){
     browser.element("//div[@class='header_user_info']").click;
And (/^enter the email address under the "Crete an account" section$/, function(){
    browser.element("//input[@id='email_create']").sendkeys("shwetha.friends@gmail.com");
})
And (/^click on "crete account" button$/, function(){    
    browser.element("//input[@id='SubmitCreate']").click();
})
And (/^click <Mrs> radio button$/, function(){ 
    browser.element("//input[@id='id_gender2']").click();
})
And (/^enter <first name>$/, function(){
    browser.element("//input[@id='customer_firstname']").sendkeys(shwetha);
})
And (/^Enter <last name>$/, function(){
    browser.element("//input[@id='customer_lastname']").sendkeys(MM);
})
And (/^enter <password> which has minimum 5 characters$/, function(){
    browser.element("//input[@id='customer_passwd']").sendkeys(Tention123);

})
And (/^select the <date of birth> from the date droplist$/, function(){
    it("select drop down value days", function(){
        $('#days').selectByVisibleText('23')
        browser.pause(3000)
        $('#months').selectByVisibleText('April')
        browser.pause(3000)
        $('#years').selectByVisibleText('1992')
        browser.pause(3000)
})
})
Then (/^verify if the <first name> and <last name> details are prepopulated by already entred details under address section$/, function(){
it("get text", function(){
    $('#firstname').getvalue(shwetha)
    $('#lastname').getvalue(MM)
})
})
When (/^enther the <companyname>$/, function(){
     browser.element("//input[@id='company']").sendkeys(Capgemini);
})
And (/^enter the <address>$/, function(){
    browser.element("//input[@id='address1']").sendkeys(DKsandra);
})
And (/^enter the city$/, function(){
    browser.element("//input[@id='city']").sendkeys(bangalore);
})
And (/^select the <state> from the dropdown$/, function(){
    it("select drop down value", function(){
        $('#id_state').selectByVisibleText('karnataka')
        browser.pause(3000)
    })
})
And (/^enter the <postalcode>$/, function(){
    browser.element("//input[@id='postcode']").sendkeys(560062)
    })
    
And (/^select the <country> from  the drop list$/, function(){
    it("select drop down value", function(){
    $('#uniform-id_country').selectByVisibleText('india')
    browser.pause(3000)
})
})

And (/^enter the <mobilenumber>$/, function(){
    browser.element("//input[@id='phone_mobile']").sendkeys(9956785431);
})
And (/^enter the <alias address>$/, function(){
    browser.element("//input[@id='alias']").sendkeys(dksandra);
})
And (/^click on the <register> button$/, function(){
    browser.element("//button[@id='submitAccount']").click();
})
Then(/^Homepage should be loaded and user able to search by categories$/, function(){
    browser.element("//input[@id='search_query_top']").setValue("printed summer wear");
    browser.element("//button[@name='submit_search']").click();
})
